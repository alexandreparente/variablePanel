<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de">
<context>
    <name>VariablePanel</name>
    <message>
        <source>&amp;Variables Panel</source>
        <translation type="vanished">&amp;Bedienfeld Variablen</translation>
    </message>
    <message>
        <source>Variables Panel</source>
        <translation type="vanished">Bedienfeld Variablen</translation>
    </message>
    <message>
        <source>Variables ToolBar</source>
        <translation type="vanished">Variablenwerkzeugleiste</translation>
    </message>
</context>
<context>
    <name>VariablePanelDockWidget</name>
    <message>
        <source>Apply</source>
        <translation type="vanished">Anwenden</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">Abbrechen</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="vanished">OK</translation>
    </message>
    <message>
        <source>Variables</source>
        <translation type="vanished">Variablen</translation>
    </message>
</context>
</TS>
