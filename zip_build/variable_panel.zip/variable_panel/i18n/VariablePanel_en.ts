<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>VariablePanel</name>
    <message>
        <location filename="../variable_panel.py" line="165"/>
        <source>&amp;Variable Panel</source>
        <translation>&amp;Variable Panel</translation>
    </message>
    <message>
        <location filename="../variable_panel.py" line="156"/>
        <source>Variable Panel</source>
        <translation>Variable Panel</translation>
    </message>
</context>
<context>
    <name>VariablePanelDockWidget</name>
    <message>
        <location filename="../variable_panel_dockwidget.py" line="44"/>
        <source>Variable Panel</source>
        <translation>Variable Panel</translation>
    </message>
    <message>
        <location filename="../variable_panel_dockwidget.py" line="59"/>
        <source>Apply</source>
        <translation>Apply</translation>
    </message>
    <message>
        <location filename="../variable_panel_dockwidget.py" line="60"/>
        <source>Cancel</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="../variable_panel_dockwidget.py" line="61"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
</TS>
