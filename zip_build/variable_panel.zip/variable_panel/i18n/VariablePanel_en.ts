<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>VariablePanel</name>
    <message>
        <location filename="../variable_panel.py" line="222"/>
        <source>&amp;Variables Panel</source>
        <translation>&amp;Variables Panel</translation>
    </message>
    <message>
        <location filename="../variable_panel.py" line="153"/>
        <source>Variables Panel</source>
        <translation>Variables Panel</translation>
    </message>
    <message>
        <location filename="../variable_panel.py" line="64"/>
        <source>Variables ToolBar</source>
        <translation>Variables ToolBar</translation>
    </message>
</context>
<context>
    <name>VariablePanelDockWidget</name>
    <message>
        <location filename="../variable_panel_dockwidget.py" line="46"/>
        <source>Variables</source>
        <translation>Variables</translation>
    </message>
</context>
</TS>
