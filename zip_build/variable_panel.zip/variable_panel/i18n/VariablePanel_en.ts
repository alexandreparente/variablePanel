<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>VariablePanel</name>
    <message>
        <source>&amp;Variables Panel</source>
        <translation type="vanished">&amp;Variables Panel</translation>
    </message>
    <message>
        <source>Variables Panel</source>
        <translation type="vanished">Variables Panel</translation>
    </message>
    <message>
        <source>Variables ToolBar</source>
        <translation type="vanished">Variables ToolBar</translation>
    </message>
</context>
<context>
    <name>VariablePanelDockWidget</name>
    <message>
        <source>Apply</source>
        <translation type="vanished">Apply</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">Cancel</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="vanished">OK</translation>
    </message>
    <message>
        <source>Variables</source>
        <translation type="vanished">Variables</translation>
    </message>
</context>
</TS>
