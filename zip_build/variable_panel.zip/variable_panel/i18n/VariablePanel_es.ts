<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es">
<context>
    <name>VariablePanel</name>
    <message>
        <location filename="../variable_panel.py" line="222"/>
        <source>&amp;Variables Panel</source>
        <translation>&amp;Panel de Variables</translation>
    </message>
    <message>
        <location filename="../variable_panel.py" line="153"/>
        <source>Variables Panel</source>
        <translation>Panel de Variables</translation>
    </message>
    <message>
        <location filename="../variable_panel.py" line="64"/>
        <source>Variables ToolBar</source>
        <translation>Barra de herramientas de variables</translation>
    </message>
</context>
<context>
    <name>VariablePanelDockWidget</name>
    <message>
        <location filename="../variable_panel_dockwidget.py" line="46"/>
        <source>Variables</source>
        <translation>Variables</translation>
    </message>
</context>
</TS>
