<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_BR">
<context>
    <name>VariablePanel</name>
    <message>
        <source>&amp;Variables Panel</source>
        <translation type="vanished">&amp;Painel de Variáveis</translation>
    </message>
    <message>
        <source>Variables Panel</source>
        <translation type="vanished">Painel de Variáveis</translation>
    </message>
    <message>
        <source>Variables ToolBar</source>
        <translation type="vanished">Barra de ferramentas de Variáveis</translation>
    </message>
</context>
<context>
    <name>VariablePanelDockWidget</name>
    <message>
        <source>Apply</source>
        <translation type="vanished">Aplicar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">Cancelar</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="vanished">OK</translation>
    </message>
    <message>
        <source>Variables</source>
        <translation type="vanished">Variáveis</translation>
    </message>
</context>
</TS>
