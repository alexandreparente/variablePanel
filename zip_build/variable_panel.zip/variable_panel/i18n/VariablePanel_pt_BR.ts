<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_BR">
<context>
    <name>VariablePanel</name>
    <message>
        <location filename="../variable_panel.py" line="224"/>
        <source>&amp;Variable Panel</source>
        <translation>&amp;Painel de variáveis</translation>
    </message>
    <message>
        <location filename="../variable_panel.py" line="154"/>
        <source>Variable Panel</source>
        <translation>Painel de variáveis</translation>
    </message>
</context>
<context>
    <name>VariablePanelDockWidget</name>
    <message>
        <location filename="../variable_panel_dockwidget.py" line="58"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../variable_panel_dockwidget.py" line="59"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../variable_panel_dockwidget.py" line="60"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../variable_panel_dockwidget.py" line="43"/>
        <source>Variable Panel</source>
        <translation>Painel de variáveis</translation>
    </message>
</context>
</TS>
